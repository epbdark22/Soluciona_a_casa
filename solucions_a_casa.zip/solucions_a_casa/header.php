<nav id="navbar" class="navbar">
      <ul>
          <li><a class="nav-link scrollto active" href="#hero">Inici</a></li>
          <li><a class="nav-link scrollto" href="#services">Reserves</a></li>
          <li><a class="nav-link   scrollto" href="#portfolio">Publica un anunci</a></li>
          <li><a class="nav-link scrollto" href="#team">Nosaltres</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contacta</a></li>
          <li><a class="nav-link scrollto" href="serveis.php">Serveis i solucions</a></li>
          <li class="d-flex material-symbols-outlined">
            <a class="nav-link scrollto" href="usuari.php">person</a>
          </li>        
      </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>