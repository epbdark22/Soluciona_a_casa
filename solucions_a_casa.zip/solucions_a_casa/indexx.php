<?php 
include "includes/header.php"; 
include "includes/conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>index</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  
    <div class="container mt-3">
        <div>
            <img src="img/logo.png" height="70" style="float: left;"/>
            <div style="padding-top: 2%; margin-left: 50px;">
              <h1>Solucions a casa</h1>
            </div>
            <input class="form-control me-sm-2" type="search" placeholder="Cercar un servei">
        </div>
        <div class="mt-4">
            <h1>
                Categories mes populars
            </h1>
        </div>
        <div class="row">
        <?php
        obrirConnexioBD();
        $sql = "SELECT DISTINCT *
                FROM servei;";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {           
        ?>
        <style>
          .card-custom {
            height: 100%;
          }

          .card-custom .card {
            height: 100%;
          }

          .card-custom .card-body {
            height: 50%;
          }

          .card-custom .card-img-top {
            height: 50%;
            object-fit: cover;
          }
        </style>
        <style>
          .card-deck-custom {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          align-items: stretch;
        }

        .card-deck-custom .card {
          width: 100%;
        }

        .card-deck-custom .card-img-top {
          height: 50%;
          object-fit: cover;
        }

        .card-deck-custom .card-body {
          height: 35%;
        }

        .card-deck-custom .card-header {
          height: 15%;
        }
        </style>
        <div class="col-md-3 my-3">
        <div class="row">
            <div class="card-deck card-deck-custom"> 
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
                <div class="card mb-3 card-custom">
                    <h3 class="card-header"><?=$row['nom_servei'];?></h3>
                    <div class="card-body">
                        <h5 class="card-title"><?=$row['descripcio_servei'];?></h5>
                    </div>
                    <img class="card-img-top" src="<?php echo $row['img'];?>">

                    <a name="" id="" class="btn btn-secondary" href="https://www.tda.ad/" role="button">Veure serveis</a>
                </div>
            </div>
        </div>
    </div>
    
    <?php
          }
        }
        $conn->close();
    ?>       

      </div>
      </div>
  <?php include "includes/footer.php"; ?>
  <script src="buscador.js"></script>
 
</body>
</html>