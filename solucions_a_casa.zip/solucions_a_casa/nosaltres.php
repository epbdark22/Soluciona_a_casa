<?php 
include "includes/header.php"; 
include "includes/conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <br>
  <br>
  <title>Nosaltres</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  
    <div class="container">
    
            <br>

        <br>
        </div>
        <style>
		.container {
			display: flex; /* Establecer el contenedor como un contenedor flexible */
			align-items: center; /* Centrar verticalmente los elementos dentro del contenedor */
		}
		.texto {
			flex: 1; /* Hacer que el texto ocupe todo el espacio restante */
			margin-right: 50px; /* Establecer un margen a la derecha para separar el texto de la imagen */
		}
		.imagen {
			width: 500px; /* Establecer el ancho deseado para la imagen */
		}
	</style>

	<div class="container">
		<div class="texto">
			<h2>Nosaltres</h2>
			<p>Després de 19 anys d’experiència, sumant una gran família de professionals i acompanyant durant aquest temps els nostres clients, podem dir que ens sentim orgullosos de contribuir a l’èxit digital del país.
        
        Tècniques d’Avantguarda té els seus inicis a Andorra, el 2002, amb el desenvolupament a mida de software. Adaptant-nos a les necessitats que el ràpid i complex progrés demanda, hem anat incorporant noves àrees de coneixement i serveis TIC (tecnologies de la informació i de la comunicació).
        
        D’una manera “glocal”, amb el coneixement de les particularitats del nostre país, amb el talent i una visió global internacional, oferim un servei complet de Business Consulting i serveis TIC.
        
        A Tècniques d’Avantguarda (TdA) acompanyem els nostres clients en la millora dels seus projectes, a través de crear i gestionar serveis de qualitat i innovadors. Si la seva empresa o entitat té una visió diferent i de futur, amb ganes d’emprendre nous camins... llavors, som el seu partner tecnològic i estratègic!
      </p> 
		</div>
		<img src="https://especialeslv.prismapublicaciones.com/sites/default/files/styles/full_image/public/bundle_resources/bundle_content_image_003/150908-2.jpg?itok=QMtH636Y" alt="Descripción de la imagen" class="imagen">
	</div>

  <div class="container">
    
    <br>

<br>
</div>
<style>
.container {
display: flex; /* Establecer el contenedor como un contenedor flexible */
align-items: center; /* Centrar verticalmente los elementos dentro del contenedor */
}
.texto2 {
flex: 1; /* Hacer que el texto ocupe todo el espacio restante */
}
.imagen2 {
width: 500px; /* Establecer el ancho deseado para la imagen */
float: left;
margin-right: 20px;
}
</style>

<div class="container">
<div class="texto2">
  <img src="https://carles68.files.wordpress.com/2022/03/3-mosqueteros_blog.jpg" class="imagen2">
  <div class="texto2">
  <h2>Equip</h2>
<p>Equipo formado por matias, toni i Pique. Duroooooooooo
</p> 
</div>
</div>

</div>

  
<br>
<br>
<br>

    
  
<?php include "includes/footer.php"; ?>
 
</body>
</html>