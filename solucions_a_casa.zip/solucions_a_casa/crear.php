<?php 
include "includes/header.php";
include "includes/conn.php";
session_start();
if (!isset($_SESSION['mail_treballador'])) {
  header("Location: login.php");
  exit();
}
?>  
<!DOCTYPE html>
<html lang="en">
    <head>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">

      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Anunci</title>
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
  
  
    <div class="container mt-6">
    <form method="post" enctype="multipart/form-data">
    <?php
    obrirConnexioBD();
    $mail = $_SESSION['mail_treballador'];
    $sql = "SELECT ID_treballador FROM treballadors WHERE mail_treballador = '$mail'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $id_treballador = $row['ID_treballador'];
    } else {
        echo "Error: " . mysqli_error($conn);
    }
    if(isset($_POST['submit'])){ //Comprobar si el formulario ha sido enviado

        //Recopilar los datos del formulario
        $id_servei = $_POST['ID_servei'];
        $nom_anunci = $_POST['nom_anunci'];
        $descripcio_anunci = $_POST['descripcio_anunci'];
        $target_file = $_FILES['imatges_anunci'];
      
        // Procesar la imagen
        $target_dir = "img/"; // directorio donde se guarda la imagen
        $target_file = $target_dir . basename($_FILES["imatges_anunci"]["name"]); // ruta completa del archivo
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        // Comprobar si es una imagen real o una imagen falsa
        if(isset($_POST["submit"])) {
          $check = getimagesize($_FILES["imatges_anunci"]["tmp_name"]);
          if($check !== false) {
            $uploadOk = 1;
          } else {
            echo "El archivo no es una imagen.";
            $uploadOk = 0;
          }
        }

        

//Consulta para insertar los datos en la tabla
$query = "INSERT INTO anunci (ID_treballador, nom_anunci, ID_servei, descripcio_anunci, imatges_anunci) VALUES ( \"$id_treballador\", \"$nom_anunci\", \"$id_servei\", \"$descripcio_anunci\", \"$target_file\")";
print_r($query);
//Ejecutar la consulta
if(mysqli_query($conn, $query)){
 echo "El formulari ha sigut enviat correctament.";
} else{
  echo "Hi ha hagut un error a l' hora d' enciar el formulari: " . mysqli_error($conn);
}
}


?> 
  <fieldset class="margin">
    <style>
      .formularis {
          padding-top: 2%;
        }
        .margin {
            margin-right: 50%;

        }
      </style>  
      <br>
      <h1>Crear Anunci<center></h1>
    <div class="form-label formularis">
        <label for="nom_anunci" class="control-label">Nom de l'anunci:</label>
        <input type="text" class="form-control" id="nom_anunci" name="nom_anunci" Required>    
    </div>      
    <div class="form-label formularis">
        <label for="ID_servei" class="control-label">Servei:</label>    
        <select class="form-control" name="ID_servei" id="ID_servei" required>
            <option selected>Selecciona un servei</option>
    <?php
    $sql = "SELECT DISTINCT s.ID_servei, s.nom_servei
            FROM servei as s;
            ";


            $result = $conn->query($sql);
            if ($result->num_rows > 0) {

                while ($row2 = $result->fetch_assoc()) {
                    $servei = $row2["ID_servei"];
                    if ($servei != '') {
                        if ($servei == $row["ID_servei"]) {
                            echo "<option value='".$row["ID_servei"]."' selected>".$row2['nom_servei']."</option>";
                        } else {
                            echo "<option value='".$row2['ID_servei']."'>".$row2['nom_servei']."</option>"; 
                        }
                    } else {
                        echo "<option value='".$row2['ID_servei']."'>".$row2['nom_servei']."</option>";   
                    }
                }
            }

    ?>
    </select>
    </div>
    <div class="form-label formularis">
        <label for="descripcio_anunci" class="control-label">Descripcio de l'aunici</label>
        <input type="text" class="form-control" id="descripcio_anunci" name="descripcio_anunci">
    </div>
    <div class="form-label formularis">
        <label for="imatges_anunci" class="control-label">Fotos</label>
        <input type="file" class="form-control" id="imatges_anunci" name="imatges_anunci" accept="image/*">
    </div>

    <div class="formularis">
        <button type="submit" name="submit" class="btn btn-primary">Enviar</button>
    </div>
    <br>
    </fieldset> 
    </form>
  </div> 
<?php
include "includes/footer.php";
?>
</body>
</html>


    </div>
    </body>
    </html>