<?php  
include "includes/header.php";
include "includes/conn.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <h1>prova</h1>
    <script type="text/plain" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-browser/2.0/jquery.browser.js"></script>
    <script>
        var loginClient = new JSONRpcClient({
            'url': 'https://solucionsacasa.simplybook.it/v2/',
            'onerror': function (error) {},
        });
        var token = loginClient.getToken('Solucionsacasa', '1e292f576a4ec9d35d16e9ccb3813b9534d760ae03b888ce1fae1f5107adc8ed');
        
    </script>
</body>
</html>
