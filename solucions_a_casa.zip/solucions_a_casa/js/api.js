
var loginClient = new JSONRpcClient({
    'url': 'https://Solucionsacasa.simplybook.it/v2/',
    'onerror': function (error) {},
  });
  var token = loginClient.getToken('Solucionsacasa', '1e292f576a4ec9d35d16e9ccb3813b9534d760ae03b888ce1fae1f5107adc8ed');
  


