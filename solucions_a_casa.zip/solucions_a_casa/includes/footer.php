<div class="footer-wrapper">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">

  <footer class="bg-primary text-center text-lg-start text-white">
    <!-- Grid container -->
    <div class="container p-4">
      <!--Grid row-->
      <style>
        .aguila{
          padding-right: 7%;
          padding-top: 1%;
        }
      </style>
      <div class="row my-2">
        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4 mb-md-0 aguila">

          <div class="rounded-circle bg-white shadow-1-strong d-flex align-items-center justify-content-center mb-3 mx-auto" style="width: 150px; height: 150px;">
            <img src="img/logo.png" height="115" alt=""
                 loading="lazy" />
          </div>

          <p class="text-center">Solucions a casa</p>
          
          <title>Botones con iconos de redes sociales</title>
  <style>
    .boton-social {
      display: inline-block;
      margin: 10px;
      padding: 10px;
      border-radius: 50%;
      text-align: center;
      width: 50px;
      height: 50px;
      color: white;
      font-size: 25px;
      text-decoration: none;
    }
    
    .boton-facebook {
      background-color: #000000;
    }
    
    .boton-instagram {
      background-color: #000000;
    }
    
    .boton-linkedin {
      background-color: #000000;
    }
  </style>

  <a href="https://www.facebook.com/TecniquesAvantguarda" target="_blank" class="boton-social boton-facebook"><i class="fab fa-facebook"></i></a>
  <a href="https://www.instagram.com/tecniques_avantguarda/" target="_blank" class="boton-social boton-instagram"><i class="fab fa-instagram"></i></a>
  <a href="https://www.linkedin.com/company/tda-andorra"  target="_blank" class="boton-social boton-linkedin"><i class="fab fa-linkedin"></i></a>

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">PIQUES</h5>

          <ul class="list">
            <li class="mb-2">
              <a href="#!" class="text-white"><i class="fas pe-3"></i>Definicio</a>
            </li>
            <li class="mb-2">
              <a href="https://www.google.es/maps/place/TdA+-+T%C3%A8cniques+d'Avantguarda/@42.5065224,1.5206233,17z/data=!4m6!3m5!1s0x12a58ae7f2f653f5:0x9e466b99ec1757e1!8m2!3d42.5065185!4d1.5231982!16s%2Fg%2F1hc11m7vl" target="_blank" class="text-white"><i class="fas pe-3"></i>Ubicació: c. Prat de la Creu, 59-65. Escala D. 2n pis. AD500 Andorra la Vella. Principat d’Andorra</a>
            </li>
            <li class="mb-2">
              <a href="tel:+376826896" class="text-white"><i class="fas pe-3"></i>Telèfon: +376 826896</a>
            </li>

          </ul>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">Columna 2</h5>

          <ul class="list-unstyled">
            <li class="mb-2">
              <a href="#!" class="text-white"><i class="fas pe-3"></i>Seccions</a>
            </li>
            <li class="mb-2">
              <a href="serveis.php" class="text-white"><i class="fas pe-3"></i>Categories i Serveis</a>
            </li>
            <li class="mb-2">
              <a href="#!" class="text-white"><i class="fas pe-3"></i>Consultoria</a>
            </li>
            <li class="mb-2">
              <a href="#!" class="text-white"><i class="fas pe-3"></i>Novetats</a>
            </li>
            <li class="mb-2">
              <a href="nosaltres.php" class="text-white"><i class="fas pe-3"></i>Nosaltres</a>
            </li>
            <li class="mb-2">
              <a href="contactar.php" class="text-white"><i class="fas pe-3"></i>Contactar</a>
            </li>

          </ul>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">Columna 3</h5>

          <ul class="list-unstyled">
          <li class="mb-2">
              <a href="admin/crearcompte.php" class="text-white"><i class="fas pe-3"></i>Treballa amb nosaltres</a>
            </li>
            <li class="mb-2">
              <a href="https://www.tda.ad/ca/politica-de-privacitat" target="_blank" class="text-white"><i class="fas pe-3"></i>Politica de privacitat</a>
            </li>
            <li class="mb-2">
              <a href="https://www.tda.ad/ca/avis-legal" target="_blank" class="text-white"><i class="fas pe-3"></i>Avis legal</a>
            </li>
            <li class="mb-2">
              <a href="https://www.tda.ad/ca/politica-de-cookies" target="_blank" class="text-white"><i class="fas pe-3"></i>Politica de cookies</a>
            </li>
          </ul>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
  © 2023 TDA - 
  <a class="text-white ms-2" href="https://www.tda.ad/" target="_blank" >Tècniques d'Avantguarda</a>
</div>
    <!-- Copyright -->
  </footer>

</div>
<!-- End of .container -->