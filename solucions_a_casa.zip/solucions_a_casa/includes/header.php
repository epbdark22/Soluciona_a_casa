<!DOCTYPE html>
<html lang="en">
<head>
  
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solucions a casa</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />

    <style>
.material-symbols-outlined {
  font-variation-settings:
  'FILL' 0,
  'wght' 400,
  'GRAD' 0,
  'opsz' 48
}
</style>
  

  


</head>
<body>
<nav class="sticky-top nav.sticky  nav nav-link navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor02">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Inici</a>
          
        </li>
        <li class="nav-item">
          <a class="nav-link" href="serveis.php">Serveis i Solucions</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="reserves.php">reserves</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="nosaltres.php">Nosaltres</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contactar.php">Contacta</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="crear.php">Publica un anunci</a>
        </li>
      </ul>
      <form id="inputBusqueda" class="d-flex">
  <input class="form-control me-sm-2" type="search" placeholder="Search">
  <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
</form>
      <li class="d-flex material-symbols-outlined">
        <a class="nav-link" href="usuari.php">person</a>
      </li>
    </div>
  </div>

</nav>
<!--
<script>
  window.onscroll = function() {myFunction()};

  var navbar = document.getElementsByTagName("nav")[0];
  var sticky = navbar.offsetTop;

  function myFunction() {
    if (window.pageYOffset >= sticky) {
      navbar.classList.add("sticky")
    } else {
      navbar.classList.remove("sticky");
    }
  }
</script>

<script src="../buscador.js"></script>
-->

</body>
</html>