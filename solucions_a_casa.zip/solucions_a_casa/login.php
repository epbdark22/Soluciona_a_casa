<?php
include "includes/conn.php";

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  </head>
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.php">Solucions a casa</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
  <?php include "header_dedicat.php";?>
  </header><!-- End Header -->

  <style>
.fixed-top {
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  z-index: 1030;
  background-color: black;
}
  </style>
  <body>
  

  <br>
  <br>
  <div class="content mt-5">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <img src="img/logo.png" alt="Image" class="img-fluid">
          </div>
        <div class="col-md-6 contents">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="mb-4">
              <h3>Inicia sessio</h3>
              <p class="mb-4">Treballa amb nosaltres iniciant sessio a solucions a casa</p>
            </div>
            <form method="post">
            <?php
              
              obrirConnexioBD(); 
              
              
              
              // Verificar si se ha enviado el formulario de inicio de sesión
              if(isset($_POST['submit'])){ //Comprobar si el formulario ha sido enviado
              
                // Obtener los valores enviados por el formulario
                $mail_treballador=$_POST['mail_treballador'];
                $pwd_treballador=$_POST['pwd_treballador'];

              
                // Consultar si existe el usuario en la base de datos
                
                $sql = "SELECT mail_treballador, pwd_treballador FROM treballadors WHERE mail_treballador='" . $mail_treballador . "' AND pwd_treballador='" . $pwd_treballador . "'";
                $result = $conn->query($sql);
                session_start();
                // ...código para validar las credenciales de inicio de sesión...
                $_SESSION['mail_treballador'] = $mail_treballador;
                              
                if ($result->num_rows == 1) {
                  // El usuario y la contraseña son correctos, redirigir a la página principal
                  header("Location: index.php");
                  exit();
                } else {
                  // El usuario y/o la contraseña son incorrectos, mostrar mensaje de error
                  $error_message = "correu o contrasenya incorrectes";
                }
              }
              
                            ?>
              <div class="form-group first">
                <label for="mail_treballador">Correu electronic</label>
                <input type="text" class="form-control" id="mail_treballador" name="mail_treballador">

              </div>
              <div class="form-group last mb-4">
              <label for="pwd_treballador">Mot clau</label>
              <input type="password" class="form-control" id="pwd_treballador" name="pwd_treballador">
              <?php if(isset($error_message)){ ?>
              <div class="text-danger"><?php echo $error_message; ?></div>
              <?php } ?>
            </div>
              
             
              <input type="submit" name="submit" value="Log In" class="btn btn-block btn-primary">

              <button class="btn btn-block btn-primary"><a href="crearcompte.php" style="color: white;">Crear compte</a></button>
             
              </div>

            </form>
            </div>
          </div>
          
        </div>
        
      </div>
    </div>
  </div>

  
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>



           
