
<?php  
include "includes/header.php";
include "includes/conn.php";
?>  

<!DOCTYPE html>
<html>
  <head>
    <title> Serveis </title>
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="container mt-3">
      <h1>Serveis</h1>
      <div class="row">
        
        <?php
          obrirConnexioBD();
          $sql = "SELECT * 
                  FROM anunci
                  INNER JOIN servei ON servei.ID_servei = anunci.ID_servei";
          $result = $conn->query($sql);
          if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {           
        ?>
        <div class="col-md-3 my-3">
            <div class="row">
                <div class="card-deck"> 
                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
                    <div class="card mb-3">
                        <h3 class="card-header"><?=$row['nom_anunci'];?></h3>
                        <div class="card-body">
                            <h5 class="card-title"><?=$row['nom_servei'];?></h5>
                            <h6 class="card-subtitle text-muted">Support card subtitle</h6>
                        </div>
                        <img class="card-img-top" src="<?php echo $row['imatges_anunci'];?>">
                        <div class="card-body">
                            <p class="card-text"><?=$row['descripcio_anunci'];?></p>
                        </div>
                        <div class="card-text">
                            <?php
                            $sql2 = "SELECT * 
                                     FROM anunci
                                     INNER JOIN treballadors ON treballadors.ID_treballador = anunci.ID_treballador
                                     WHERE anunci.ID_anunci = " . $row['ID_anunci'];
                            $result2 = $conn->query($sql2);
                            if ($result2->num_rows > 0) {
                                while($row2 = $result2->fetch_assoc()) {           
                                    ?>
                            <p class="list-group-item"><?=$row2['nom_treballador'];?></p>
                            <?php
                                }
                            }
                            ?>
                        <a name="" id="" class="btn btn-secondary" href="https://www.buscocotxe.ad/" role="button">
                       Veure anunci
                        </a>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
            }
        }
        $conn->close();
        ?>       
      </div>
    </div>
    <?php include "includes/footer.php"; ?> 
  </body>
</html>