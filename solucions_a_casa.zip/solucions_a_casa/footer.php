<!-- ======= Footer ======= -->
<footer id="footer">

<div class="footer-newsletter">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-6">
        <h4>Uneix-te a la nostra revista</h4>
        <p>Noticies, blog, actualitat</p>
        <form action="" method="post">
          <input type="email" name="email"><input type="submit" value="Subscribe">
        </form>
      </div>
    </div>
  </div>
</div>

<div class="footer-top">
  <div class="container">
    <div class="row">
    
      <div class="col-lg-3 col-md-6 footer-contact">
        <h3>Solucions a casa</h3>
        <p>
        <strong>Ubicació:</strong>
         <a href="https://www.google.com/maps/place/T%C3%A8cniques+d'Avantguarda/@42.5065185,1.5206233,17z/data=!3m1!4b1!4m6!3m5!1s0x12a58ae7f2f653f5:0x9e466b99ec1757e1!8m2!3d42.5065185!4d1.5231982!16s%2Fg%2F1hc11m7vl" 
         target="_blank">Carrer Prat de la Creu, 59-65. Escala D.<br>
          2a planta, AD500 Andorra la Vella</a> <br> <br>


          <strong>Phone:</strong> <a href="tel:+376 826.896" onclick="window.location.href = 'tel:+376 826.896';">+376 826.896</a> <br>
          <strong>Email:</strong> <a href="mailto:info@tda.ad">info@tda.ad</a>

        </p>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Links</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="index.php">Inici</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#team">Nosaltres</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#portfolio">Serveis i solucions</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="https://www.tda.ad/ca/avis-legal" target="_blank">Avís legal</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="https://www.tda.ad/ca/politica-de-privacitat" target="_blank">Política de privacitat</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="https://www.tda.ad/ca/politica-de-cookies" target="_blank">Política de cookies</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Els nostres serveis</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="#contact">Treballa amb Nosaltres </a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="https://www.tda.ad/ca/consultoria" target="_blank">Consultoria</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Les nostres xarxes socials</h4>
        <p>Segueixnos</p>
        <div class="social-links mt-3">
          <a href="https://www.facebook.com/TecniquesAvantguarda"target="_blank" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="https://www.instagram.com/tecniques_avantguarda/"target="_blank" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="https://www.linkedin.com/company/tda-andorra?original_referer="target="_blank" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="container footer-bottom clearfix">
  <div class="copyright">
    &copy; Copyright <strong><span>Solucions a casa</span></strong>. All Rights Reserved
  </div>
  <div class="credits">
    Designed by <a href="https://tda.ad" target="_blank">Tecniques d'Avantguarda</a>
  </div>
</div>
</footer>
