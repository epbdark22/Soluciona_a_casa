<nav id="navbar" class="navbar">
      <ul>
          <li><a class="nav-link scrollto" href="index.php">Tornar</a></li>       
      </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>