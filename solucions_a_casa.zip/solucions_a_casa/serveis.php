
<?php  
include "includes/conn.php";
?>  

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Serveis</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
   <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.php">Solucions a casa</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
  <?php include "header_dedicat.php";?>
  </header><!-- End Header -->
  <br>
  <br>
  <style>
    .fixed-top {
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  z-index: 1030;
  background-color: black;
}

  </style>
    <div class="container mt-5">
      <h1>Serveis</h1>
      <div class="row">
        
        <?php
          obrirConnexioBD();
          $sql = "SELECT * 
                  FROM anunci
                  INNER JOIN servei ON servei.ID_servei = anunci.ID_servei";
          $result = $conn->query($sql);
          if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {           
        ?>
        <div class="col-md-3 my-3">
            <div class="row">
                <div class="card-deck" style="width: 18rem;"> 
                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
                    <div class="card mb-3">
                        <h3 class="card-header"><?=$row['nom_anunci'];?></h3>
                        <div class="card-body">
                            <h5 class="card-title"><?=$row['nom_servei'];?></h5>
                        <?php
                        $sql2 = "SELECT nom_treballador, cognom_treballador 
                                FROM treballadors 
                                INNER JOIN anunci ON treballadors.ID_treballador = anunci.ID_treballador
                                WHERE anunci.ID_anunci = ".$row['ID_anunci'];
                        $result2 = $conn->query($sql2);
                        if ($result2->num_rows > 0) {
                            while($row2 = $result2->fetch_assoc()) {           
                        ?>
                        <span class="card-subtitle"><?=$row2['nom_treballador'];?> <?=$row2['cognom_treballador'];?></span>
                        <?php
                            }
                        }
                        ?>
                        </div>
                        <img class="card-img-top" src="<?php echo $row['imatges_anunci'];?>">
                        <div class="card-body">
                            <p class="card-text"><?=$row['descripcio_anunci'];?></p>
                        </div>
                        <a name="" id="" class="btn btn-secondary" href="https://www.buscocotxe.ad/" role="button">Veure anunci</a>

                    </div>
                    </div>
                </div>
            </div>
        <?php
            }
        }
        $conn->close();
        ?>       
      </div>
    </div>
    <?php
    include "footer.php";
    ?>
  </body>
</html>