<?php 
  include "includes/conn.php";
  obrirConnexioBD();
  session_start();
  if (!isset($_SESSION['mail_treballador'])) {
    header("Location: login.php");
    exit();
  }
  $mail_treballador = $_SESSION['mail_treballador'];
  $sql = "SELECT * FROM treballadors WHERE mail_treballador ='" . $mail_treballador . "'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc(); // obtener una fila como arreglo asociativo
  if(isset($_POST['modificar'])) {
    $telefon_treballador = $_POST['telefon_treballador'];
    $direccio_treballador = $_POST['direccio_treballador'];
    // actualizar los datos del trabajador en la base de datos
    $sql = "UPDATE treballadors SET telefon_treballador='$telefon_treballador', direccio_treballador='$direccio_treballador'WHERE mail_treballador='$mail_treballador'";
    $conn->query($sql);
    // redirigir al usuario de vuelta a la página de información del trabajador
    header("Location: usuari.php");
    exit();
  }
?>
<style>
    .margin{
        margin-right: 25%;
        margin-left: 25%;
    } 
    .fixed-top {
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  z-index: 1030;
  background-color: black;
}
    </style>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Ususari</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <!-- Google Fonts -->
   <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
   <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
   <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  </head>
  <body>
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">
      <h1 class="logo me-auto"><a href="index.php">Solucions a casa</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
  <?php 
  include "header_dedicat.php";
  ?>
</header><!-- End Header -->
<br>
<br>
<div class="margin mt-5">
    <h1>Modificar dades del usuari</h1>  
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
    <div class="form-group first">
        <label for="telefon_treballador">Teléfono:</label>
        <input type="text" class="form-control" id="telefon_treballador" name="telefon_treballador" value="<?php echo $row['telefon_treballador']; ?>" required>
    </div>    
    <div class="form-group first">
        <label for="direccio_treballador">Domicilio:</label>
        <input type="text" class="form-control" id="direccio_treballador" name="direccio_treballador" value="<?php echo $row['direccio_treballador']; ?>" required>
    </div>    
    <div>
        <br>
        <input class="btn btn-block btn-primary" type="submit" name="modificar" value="Modificar">
    </div>    
</form>

<?php tancarConnexioBD(); ?>
</div>
</body>
</html>

