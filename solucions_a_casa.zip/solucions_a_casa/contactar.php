<?php 
include "includes/header.php";
include "includes/conn.php";
?>  
<!DOCTYPE html>
<html lang="en">
    <head>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">

      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contactar</title>
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
  
    
    <?php
    obrirConnexioBD();
    if(isset($_POST['submit'])){ //Comprobar si el formulario ha sido enviado
      
      //Recopilar los datos del formulario
      $nom_contactar = $_POST['nom_contactar'];
      $correu_contactar = $_POST['correu_contactar'];
$telefon_contactar = $_POST['telefon_contactar'];
$asumpte_contactar = $_POST['asumpte_contactar'];

//Consulta para insertar los datos en la tabla
$query = "INSERT INTO contactar (nom_contactar, correu_contactar, telefon_contactar, asumpte_contactar) VALUES ('$nom_contactar', '$correu_contactar', '$telefon_contactar', '$asumpte_contactar')";

//Ejecutar la consulta
if(mysqli_query($conn, $query)){
  echo "El formulari ha sigut enviat correctament.";
} else{
  echo "Hi ha hagut un error a l' hora d' enciar el formulari: " . mysqli_error($conn);
}
}


?> 


<div class="container">
  <div class="formulario">
    <form method="post">

<fieldset class="margin">
  <style>
    .colors {
      margin-top: 5%;
      margin-bottom: 0.5rem;
      font-weight: 600;
      line-height: 1.2;
      color: #000000;
    }
    .container {
      display: flex;
      flex-direction: row;
    }
    
    .formulario {
      flex: 1;
      padding-right: 20px;
    }
    
    .ubicacion {
      flex: 1;
    }  

    </style>  

<h1 class="colors">Contactar</h1>

    
      <div class="form-group">
        <label for="nom_contactar" class="form-label mt-4">Nom</label>
        <input type="text" class="form-control" id="nom_contactar" name="nom_contactar" aria-describedby="nom" placeholder="Introdueix el teu nom" Required >    
      </div>
      
      <div class="form-group">
        <label for="correu_contactar" class="form-label mt-4">Correu electronic</label>
        <input type="text" class="form-control" id="correu_contactar" name="correu_contactar" aria-describedby="emailHelp" placeholder="Introdueix el correu electronic" Required >
      </div>
      <div class="form-group">
        <label for="telefon_contactar" class="form-label mt-4">Telefon</label>
        <input type="number" class="form-control" id="telefon_contactar" name="telefon_contactar" aria-describedby="telefon" placeholder="Introdueix el numero de telefon" Required >
      </div>
      <div class="form-group">
        <label for="asumpte_contactar" class="form-label mt-4">Asumpte</label>
        <textarea  type="text" class="form-control" id="asumpte_contactar" name="asumpte_contactar" rows="3" placeholder="Escriu el motiu pel qual ens contacta" Requiered></textarea>
      </div>
      <button type="submit" name="submit" class="form-label mt-4 btn btn-primary abajo">Enviar</button>
      </div>
    </fieldset> 
    <div class="ubicacion">           
      <h1 class="colors">Ubicació</h1>  
      <br>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2941.295758364602!2d1.5210095152162992!3d42.50652243383254!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a58ae7f2f653f5%3A0x9e466b99ec1757e1!2sT%C3%A8cniques%20d&#39;Avantguarda!5e0!3m2!1sca!2sad!4v1679578856163!5m2!1sca!2sad" width="600" height="450" style="border:0;" allowfullscreen=""  loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> 
    </div>
  </form>
  </div> 
  <?php
  include "includes/footer.php";
  ?>
</body>
</html>


    </div>
    </body>
    </html>