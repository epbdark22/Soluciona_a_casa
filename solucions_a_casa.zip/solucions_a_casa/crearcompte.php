<?php 
include "includes/conn.php";

obrirConnexioBD();

if(isset($_POST['submit'])){

  //Recopilar los datos del formulario
  $nom_treballador = $_POST['nom_treballador'];
  $cognom_treballador = $_POST['cognom_treballador'];
  $telefon_treballador = $_POST['telefon_treballador'];
  $mail_treballador = $_POST['mail_treballador'];
  $pwd_treballador = $_POST['pwd_treballador'];
  $direccio_treballador = $_POST['direccio_treballador'];
  $DNI = $_POST['DNI'];

  //Consulta para buscar el correo electrónico en la tabla
  $query = "SELECT mail_treballador FROM treballadors WHERE mail_treballador = '$mail_treballador'";
  $result = mysqli_query($conn, $query);

  //Comprobar si el correo electrónico ya existe
  if(mysqli_num_rows($result) > 0){
    echo "Aquest correu electrònic ja està en ús.";
  } else {
    //Consulta para insertar los datos en la tabla
    $query = "INSERT INTO treballadors (nom_treballador, cognom_treballador, telefon_treballador, mail_treballador, pwd_treballador, direccio_treballador, DNI) VALUES ('$nom_treballador', '$cognom_treballador', '$telefon_treballador', '$mail_treballador', '$pwd_treballador', '$direccio_treballador', '$DNI')";

    //Ejecutar la consulta
    if(mysqli_query($conn, $query)){
      echo "El formulari ha sigut creat correctament.";
    } else{
      echo "Hi ha hagut un error a l' hora de crear el compte: " . mysqli_error($conn);
    }
  }
}

tancarConnexioBD();

?> 



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  </head>
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.php">Solucions a casa</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
  <?php include "header_dedicat.php";?>
  </header><!-- End Header -->
  <style>
.fixed-top {
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  z-index: 1030;
  background-color: black;
}
  </style>
  <body>
    <div class="container mt-4">
      <form method="post">
        <br>
        <br>
        <br>
        <fieldset>
          <style>
            .colors {
              margin-top: 0;
              margin-bottom: 0.5rem;
              font-weight: 600;
              line-height: 1.2;
              color: #000000;
            }
          </style>

          <h1 class="colors"><center>Crear compte<center></h1>
    
          <div class="form-group">
            <label for="nom_treballador" class="form-label mt-4">Nom</label>
            <input type="text" class="form-control" id="nom_treballador" name="nom_treballador" required>
            <div class="form-group">
        <label for="cognom_treballador" class="form-label mt-4">Cognoms</label>
        <input type="text" class="form-control" id="cognom_treballador" name="cognom_treballador" required>
      </div>

      <div class="form-group">
        <label for="telefon_treballador" class="form-label mt-4">Telèfon</label>
        <input type="tel" class="form-control" id="telefon_treballador" name="telefon_treballador" required>
      </div>

      <div class="form-group">
        <label for="mail_treballador" class="form-label mt-4">Correu electrònic</label>
        <input type="email" class="form-control" id="mail_treballador" name="mail_treballador" required>
      </div>

      <div class="form-group">
        <label for="pwd_treballador" class="form-label mt-4">Contrasenya</label>
        <input type="password" class="form-control" id="pwd_treballador" name="pwd_treballador" required>
      </div>

      <div class="form-group">
        <label for="direccio_treballador" class="form-label mt-4">Adreça</label>
        <input type="text" class="form-control" id="direccio_treballador" name="direccio_treballador" required>
      </div>

      <div class="form-group">
        <label for="DNI" class="form-label mt-4">DNI</label>
        <input type="text" class="form-control" id="DNI" name="DNI" required>
      </div>

      <div class="form-group"> 
        <button type="submit" name="submit" class="btn btn-primary mt-4">Crear Compte</button>
      </div>
    </fieldset>
  </form>
</div>
</body>
</html>